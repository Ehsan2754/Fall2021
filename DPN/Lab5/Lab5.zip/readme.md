# XMLRPC python client/server program
* Use ```SERVER_FILES``` as server file directory
* Use ```CLIENT_FILES``` as client file directory
* Make sure you don't have spacing in *FILE_NAME* for either client or server